package com.softjourn.sj_coin.presenters;

public interface ILoginSessionPresenter {
    void callLogin();

    void callAccessTokenViaRefresh();
}

package com.softjourn.sj_coin.activities.fragments;

import com.softjourn.sj_coin.model.products.Product;

import java.util.List;

/**
 * Created by Ad1 on 04.08.2016.
 */
public interface IProductsListFragment {
    void loadData(List<Product> data);
}

package com.softjourn.sj_coin.presenters;

/**
 * Created by Ad1 on 10.08.2016.
 */
public interface IBalancePresenter {
    void callBalance();
}
